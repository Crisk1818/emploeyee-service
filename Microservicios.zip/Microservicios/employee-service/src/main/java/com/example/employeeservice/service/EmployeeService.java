package com.example.employeeservice.service;

import com.example.employeeservice.dto.DepartamentDTO;
import com.example.employeeservice.dto.RestponseDTO;
import com.example.employeeservice.entity.Employee;
import com.example.employeeservice.repository.EmployeeRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@AllArgsConstructor
public class EmployeeService {
    private final EmployeeRepository employeeRepository;
    private final RestTemplate restTemplate;
    public Employee saveEmployee(Employee employee){
        return employeeRepository.save(employee);
    }

    public RestponseDTO getEmployeeById(Integer id){
        RestponseDTO restponseDTO = new RestponseDTO();
        Employee employee = new Employee();
        employee = employeeRepository.findById(id).get();

        ResponseEntity<DepartamentDTO> responseEntity = restTemplate.getForEntity("http://localhost:8080/api/departaments/"+employee.getDepartamentId(), DepartamentDTO.class);

        DepartamentDTO departamentDTO = responseEntity.getBody();

        restponseDTO.setEmployee(employee);
        restponseDTO.setDepartamentDTO(departamentDTO);
        return restponseDTO;


    }
}
