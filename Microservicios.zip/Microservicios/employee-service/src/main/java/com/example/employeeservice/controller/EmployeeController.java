package com.example.employeeservice.controller;

import com.example.employeeservice.dto.RestponseDTO;
import com.example.employeeservice.entity.Employee;
import com.example.employeeservice.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/employee")
@AllArgsConstructor
public class EmployeeController {
    private final EmployeeService employeeService;

    @PostMapping
    public Employee saveEmployee(@RequestBody Employee employee){
        return employeeService.saveEmployee(employee);
    }

    @GetMapping("/{id}")
    public RestponseDTO getEmployeeById(@PathVariable Integer id){
        return employeeService.getEmployeeById(id);
    }

}
