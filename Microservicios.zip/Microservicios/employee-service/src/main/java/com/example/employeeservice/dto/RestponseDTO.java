package com.example.employeeservice.dto;

import com.example.employeeservice.entity.Employee;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RestponseDTO {

    private Employee employee;
    private DepartamentDTO departamentDTO;


}
