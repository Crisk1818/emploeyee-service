package com.example.departamentservice.repository;

import com.example.departamentservice.entity.Departament;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartamentRepository extends JpaRepository<Departament, Integer> {


}
