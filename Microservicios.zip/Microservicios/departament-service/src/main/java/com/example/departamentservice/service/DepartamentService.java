package com.example.departamentservice.service;

import com.example.departamentservice.entity.Departament;
import com.example.departamentservice.repository.DepartamentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartamentService {
    private final DepartamentRepository departamentRepository;

    public DepartamentService(DepartamentRepository departamentRepository) {
        this.departamentRepository = departamentRepository;
    }

    public Departament createDepartament (Departament departament){
        return departamentRepository.save(departament);
    }
    public Departament getDepartamentbyId(Integer id){
        return departamentRepository.findById(id).get();
    }

    public List<Departament> findall(){
        return departamentRepository.findAll();
    }

}
